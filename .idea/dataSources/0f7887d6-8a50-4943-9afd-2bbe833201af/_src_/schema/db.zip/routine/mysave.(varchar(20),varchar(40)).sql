CREATE PROCEDURE `mysave`(`n` VARCHAR(20), `a` VARCHAR(40))
  BEGIN 
        INSERT INTO student VALUES (null,n,a);    
    END