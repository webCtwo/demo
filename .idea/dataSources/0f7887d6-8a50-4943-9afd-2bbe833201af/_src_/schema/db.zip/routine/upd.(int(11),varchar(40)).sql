CREATE PROCEDURE `upd`(`ssid` INT(11), `a` VARCHAR(40))
  BEGIN
      update student set address=a where id=ssid;
    END