CREATE PROCEDURE `del`(`sid` INT(11))
  BEGIN 
      DELETE FROM student where id=sid;
    END